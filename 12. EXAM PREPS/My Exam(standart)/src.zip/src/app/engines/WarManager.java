package app.engines;

import app.contracts.Arena;
import app.contracts.ComicCharacter;
import app.contracts.SuperPower;
import app.utils.Constants;

import java.util.ArrayList;
import java.util.List;

public class WarManager {

    private List<Arena> arenas = new ArrayList<>();
    private List<ComicCharacter> characters = new ArrayList<>();
    private List<SuperPower> superPowers = new ArrayList<>();

    public WarManager() {
    }

    public String checkComicCharacter(String characterName) {
        ComicCharacter currentChar = null;

        for (ComicCharacter character : this.characters) {
            if (character.getName().equals(characterName)) {
                currentChar = character;
                break;
            }
        }

        if (currentChar == null) {
            return String.format(Constants.CHARACTED_DO_NOT_EXIST, characterName);
        }

        if (currentChar.getHealth() <= 0) {
            return String.format(Constants.DEAD_CHARACTER, characterName);
        }

        return currentChar.toString();
    }

    public String addHero(ComicCharacter hero) {
        ComicCharacter current = null;

        for (ComicCharacter character : this.characters) {
            if (character.getName().equals(hero.getName())) {
                current = character;
                break;
            }
        }

        if (current == null) {
            this.characters.add(hero);
            return String.format(Constants.HERO_ADDED, hero.getName());
        }

        this.characters.remove(current);
        this.characters.add(hero);
        return String.format(Constants.HERO_EVOLVED, hero.getName());
    }

    public String addAntiHero(ComicCharacter antiHero) {
        ComicCharacter current = null;

        for (ComicCharacter character : this.characters) {
            if (character.getName().equals(antiHero.getName())) {
                current = character;
                break;
            }
        }

        if (current == null) {
            this.characters.add(antiHero);
            return String.format(Constants.ANTIHERO_ADDED, antiHero.getName());
        }

        this.characters.remove(current);
        this.characters.add(antiHero);
        return String.format(Constants.ANTIHERO_EVOLVED, antiHero.getName());
    }

    public String addArena(Arena arena) {
        for (Arena currentArena : this.arenas) {
            if (arena.getArenaName().equals(currentArena.getArenaName())) {
                return Constants.ARENA_EXISTS;
            }
        }

        this.arenas.add(arena);
        return String.format(Constants.ARENA_CREATED, arena.getArenaName());
    }

    public String addHeroToArena(String arenaName, String hero) {
        Arena arena = null;
        for (Arena current : arenas) {
            if (current.getArenaName().equals(arenaName)) {
                arena = current;
                break;
            }
        }

        if (arena.isArenaFull()) {
            return "Arena is full!\n\r";
        }

        for (ComicCharacter current : arena.getHeroes()) {
            if (current.getName().equals(hero)) {
                if (current.getHealth() <= 0) {
                    return String.format("%s is dead!", hero);
                }
                return String.format("%s is fighting!%n", hero);
            }
        }

        ComicCharacter character = null;
        for (ComicCharacter comicCharacter : characters) {
            if (comicCharacter.getName().equals(hero)) {
                character = comicCharacter;
            }
        }
        arena.addHero(character);

        return String.format("%s is fighting for your freedom in %s!%n", hero, arenaName);
    }

    public String addAntiHeroToArena(String arenaName, String antiHero) {
        Arena arena = null;
        for (Arena current : arenas) {
            if (current.getArenaName().equals(arenaName)) {
                arena = current;
                break;
            }
        }

        if (arena.isArenaFull()) {
            return "Arena is full!\n\r";
        }

        for (ComicCharacter current : arena.getHeroes()) {
            if (current.getName().equals(antiHero)) {
                if (current.getHealth() <= 0) {
                    return String.format("%s is dead!", antiHero);
                }
                return String.format("%s is fighting!%n", antiHero);
            }
        }

        ComicCharacter character = null;
        for (ComicCharacter comicCharacter : characters) {
            if (comicCharacter.getName().equals(antiHero)) {
                character = comicCharacter;
                break;
            }
        }
        arena.addHero(character);

        return String.format("%s and his colleagues are trying to take over %s!%n", antiHero, arenaName);
    }

    public String loadSuperPowerToPool(SuperPower superPower) {
        if (this.superPowers.contains(superPower)) {
            return "This super power already exists!";
        }

        this.superPowers.add(superPower);
        return String.format("%s added to pool!%n", superPower.getName());
    }

    public String assignSuperPowerToComicCharacter(String comicCharacter, String superPower) {

        ComicCharacter character = null;
        for (ComicCharacter current : characters) {
            if (current.getName().equals(comicCharacter)) {
                character = current;
            }
        }

        for (SuperPower current : character.getPowers()) {
            if (superPower.equals(current.getName())) {
                return String.format("%s already assigned!%n", superPower);
            }
        }

        SuperPower power = null;
        for (SuperPower superPower1 : superPowers) {
            if (superPower1.getName().equals(superPower)) {
                power = superPower1;
            }
        }

        character.addSuperPower(power);
        return String.format("%s has a new super power!%n", comicCharacter);
    }

    public String usePowers(String characterName) {
        ComicCharacter character = null;
        for (ComicCharacter comicCharacter : characters) {
            if (comicCharacter.getName().equals(characterName)) {
                character = comicCharacter;
            }
        }

        if (character.getPowers().size() == 0) {
            return String.format("%s has no super powers!%n", characterName);
        }

        character.useSuperPowers();
        return String.format("%s used his super powers!%n", characterName);
    }

    public String startBattle(String arena) {
        Arena current = null;
        for (Arena arena1 : arenas) {
            if (arena.equals(arena1.getArenaName())) {
                current = arena1;
                break;
            }
        }

        if (current == null) {
            return Constants.EMPTY_STRING;
        }

        if (current.getHeroes().size() == 0 && current.getAntiHeroes().size() == 0) {
            return "SAFE ZONE!\r\n";
        }

        this.arenas.remove(current);

        while (true) {

            int heroesCount = current.getHeroes().size();
            int antiheroesCount = current.getAntiHeroes().size();


            if (heroesCount >= antiheroesCount) {
                for (int i = 0; i < current.getAntiHeroes().size(); i++) {
                    double strike = current.getAntiHeroes().get(i).attack();
                    current.getHeroes().get(i).takeDamage(strike);

                    if (current.getHeroes().get(i).getHealth() <= 0) {
                        current.getHeroes().remove(current.getHeroes().get(i));
                    }
                }
            } else {
                for (int i = 0; i < current.getHeroes().size(); i++) {
                    double strike = current.getHeroes().get(i).attack();
                    current.getAntiHeroes().get(i).takeDamage(strike);

                    if (current.getAntiHeroes().get(i).getHealth() <= 0) {
                        current.getAntiHeroes().remove(current.getAntiHeroes().get(i));
                    }
                }
            }

            if (current.getHeroes().size() == 0) {
                return String.format("Anti Heroes won the battle of %s!%n", current.getArenaName());
            }

            if (current.getAntiHeroes().size() == 0) {
                return String.format("Anti Heroes won the battle of %s!%n", current.getArenaName());
            }
        }
    }

    public String endWar() {
        return "UNDONE ENDMETHOD METHOD";
    }

}
